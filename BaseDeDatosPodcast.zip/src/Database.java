import java.sql.*;
import javafx.collections.*;

public class Database {
    private static final String URL = "jdbc:oracle:thin:@localhost:1521:xe";
    private static final String USER = "TU_USUARIO";
    private static final String PASSWORD = "TU_CONTRASEÑA";

    public static ObservableList<UserScore> fetchUserScores() {
        ObservableList<UserScore> list = FXCollections.observableArrayList();
        String query = """
            SELECT u.nombre, COUNT(p.id_puntuacion) AS total_valoraciones, SUM(p.valor) AS suma_puntuaciones
            FROM Puntuacion p
            JOIN Usuario u ON p.id_usuario = u.id_usuario
            GROUP BY u.nombre
            HAVING SUM(p.valor) > 0
            ORDER BY suma_puntuaciones DESC
        """;

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                String nombre = rs.getString("nombre");
                int total = rs.getInt("total_valoraciones");
                int suma = rs.getInt("suma_puntuaciones");
                list.add(new UserScore(nombre, total, suma));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }
}
