import javafx.beans.property.*;

public class UserScore {
    private final StringProperty usuario;
    private final IntegerProperty totalValoraciones;
    private final IntegerProperty sumaPuntuaciones;

    public UserScore(String usuario, int totalValoraciones, int sumaPuntuaciones) {
        this.usuario = new SimpleStringProperty(usuario);
        this.totalValoraciones = new SimpleIntegerProperty(totalValoraciones);
        this.sumaPuntuaciones = new SimpleIntegerProperty(sumaPuntuaciones);
    }

    public StringProperty usuarioProperty() {
        return usuario;
    }

    public IntegerProperty totalValoracionesProperty() {
        return totalValoraciones;
    }

    public IntegerProperty sumaPuntuacionesProperty() {
        return sumaPuntuaciones;
    }
}
