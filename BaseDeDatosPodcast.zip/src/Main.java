import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.collections.*;

public class Main extends Application {

    private TableView<UserScore> table = new TableView<>();

    @Override
    public void start(Stage stage) {
        stage.setTitle("Usuarios y Puntuaciones");

        TableColumn<UserScore, String> userCol = new TableColumn<>("Usuario");
        userCol.setCellValueFactory(data -> data.getValue().usuarioProperty());

        TableColumn<UserScore, Integer> totalValCol = new TableColumn<>("Total Valoraciones");
        totalValCol.setCellValueFactory(data -> data.getValue().totalValoracionesProperty().asObject());

        TableColumn<UserScore, Integer> sumaValCol = new TableColumn<>("Suma Puntuaciones");
        sumaValCol.setCellValueFactory(data -> data.getValue().sumaPuntuacionesProperty().asObject());

        table.getColumns().addAll(userCol, totalValCol, sumaValCol);

        ObservableList<UserScore> data = Database.fetchUserScores();
        table.setItems(data);

        VBox root = new VBox(table);
        Scene scene = new Scene(root, 600, 400);
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}
